package com.example.kidsvideo

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * متصفح بسيط لتشغيل YouTube وأي فيديو على الشاشة الخلفية للأطفال.
 * - ملء الشاشة للفيديو
 * - إبقاء الشاشة مضاءة
 * - "وضع الأطفال": يخفي شريط العنوان ويثبّت التطبيق (Screen Pinning)
 *   ولا يمكن الخروج منه إلا بالضغط المطوّل على الزاوية العلوية اليسرى.
 */
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var webView: WebView
    private lateinit var urlField: EditText
    private lateinit var fullscreenHost: FrameLayout
    private lateinit var unlockCorner: View

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var kidMode = false

    private val homeUrl = "https://m.youtube.com"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---------- شريط التحكم ----------
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#202020"))
            setPadding(8, 8, 8, 8)
            gravity = Gravity.CENTER_VERTICAL
        }

        urlField = EditText(this).apply {
            hint = "ابحث أو اكتب رابطاً"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    loadFromInput(text.toString()); true
                } else false
            }
        }
        topBar.addView(urlField, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        topBar.addView(makeButton("اذهب") { loadFromInput(urlField.text.toString()) })
        topBar.addView(makeButton("YouTube") { webView.loadUrl(homeUrl) })
        topBar.addView(makeButton("🔒 أطفال") { enterKidMode() })

        column.addView(topBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---------- WebView ----------
        webView = WebView(this)
        column.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(column, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // طبقة ملء الشاشة للفيديو
        fullscreenHost = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        root.addView(fullscreenHost, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // زاوية فك القفل (ضغط مطوّل)
        unlockCorner = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            visibility = View.GONE
            setOnLongClickListener { exitKidMode(); true }
        }
        root.addView(unlockCorner, FrameLayout.LayoutParams(160, 160, Gravity.TOP or Gravity.START))

        setContentView(root)
        setupWebView()

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(homeUrl)
        }
    }

    private fun makeButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptCookie(true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // أبقِ كل الروابط داخل التطبيق
                return false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!urlField.hasFocus()) urlField.setText(url ?: "")
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden(); return
                }
                customView = view
                customViewCallback = callback
                fullscreenHost.addView(view, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                fullscreenHost.visibility = View.VISIBLE
                hideSystemBars()
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                fullscreenHost.removeView(v)
                fullscreenHost.visibility = View.GONE
                customViewCallback?.onCustomViewHidden()
                customView = null
                customViewCallback = null
                if (!kidMode) showSystemBars()
            }
        }
    }

    private fun loadFromInput(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(input, "UTF-8")
        }
        webView.loadUrl(url)
        urlField.clearFocus()
    }

    // ---------- وضع الأطفال ----------
    private fun enterKidMode() {
        kidMode = true
        topBar.visibility = View.GONE
        unlockCorner.visibility = View.VISIBLE
        hideSystemBars()
        try {
            startLockTask() // تثبيت الشاشة: يمنع الخروج من التطبيق بالخطأ
        } catch (_: Exception) {
        }
    }

    private fun exitKidMode() {
        kidMode = false
        try {
            stopLockTask()
        } catch (_: Exception) {
        }
        topBar.visibility = View.VISIBLE
        unlockCorner.visibility = View.GONE
        showSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    @Suppress("DEPRECATION")
    private fun showSystemBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> webView.webChromeClient?.onHideCustomView()
            kidMode -> { /* تجاهل زر الرجوع في وضع الأطفال */ }
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
